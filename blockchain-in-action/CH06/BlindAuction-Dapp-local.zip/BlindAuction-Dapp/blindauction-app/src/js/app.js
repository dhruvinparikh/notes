App = {
    web3:null,
    contracts: {},
    names: new Array(),
    url:'http://127.0.0.1:7545',
    network_id:5777,
    chairPerson:null,
    currentAccount:null,
    biddingPhases: {
        "AuctionInit": "0",
        "BiddingStarted": "1",
        "RevealStarted": "2",
        "AuctionEnded": "3",
    },
    auctionPhases: {
        "0": "Bidding Not Started",
        "1": "Bidding Started",
        "2": "Reveal Started",
        "3":"Auction Ended"
    },

    init: function() {
      return App.initWeb3();
    },
  
    initWeb3: function() {
      if (typeof web3 !== 'undefined') {
        App.web3 = new Web3(Web3.givenProvider);
      } else {
        App.web3 = new Web3(App.url);
      }
      ethereum.enable();      
      return App.initContract(); 
    },
  
    initContract: function() {
        $.getJSON('BlindAuction.json', function(data) {
            App.contracts.BlindAuction = new App.web3.eth.Contract(data.abi, data.networks[App.network_id].address, {});  
            App.web3.eth.getAccounts().then(a=>{
             App.currentAccount=a[0];
             jQuery('#current_account').text(App.currentAccount);
             App.web3.eth.getBalance(App.currentAccount).then((res)=>{
              jQuery('#balance').text(App.web3.utils.fromWei(res),"ether");
             } )
            })                      
            jQuery('#contractAddress').text(data.networks[5777].address);
           
            
            App.getCurrentPhase();  //get current phase
            App.getChairperson();   // get the chairperson

            return App.bindEvents();
        });
    },
  
    bindEvents: function() {
        // $(document).on('click', '#submit-bid', App.handleBid);
        $(document).on('click', '#change-phase', App.handlePhase);
        $(document).on('click', '#close-auction', App.handleClose);
        $(document).on('click', '#submit-bid', App.handleBid);
        $(document).on('click', '#withdraw-bid', App.handleWithdraw);
        $(document).on('click', '#generate-winner', App.handleWinner);
        $(document).on('click', '#submit-reveal', App.handleReveal);  
    },
    getCurrentPhase : function(){
      App.contracts.BlindAuction.methods.currentPhase()
      .call()
      .then((r)=>{
          App.currentPhase=r;
          var notificationText = App.auctionPhases[App.currentPhase];
          $('.phase-notification-text').text(notificationText);
      })
    },
  
    getChairperson : function(){
      App.contracts.BlindAuction.methods.beneficiary()
      .call()
      .then((r)=>{
          App.chairPerson =r;
          if(App.currentAccount==App.chairPerson){
              $("#chairperson").css("display", "block");
          }else{
              $("#bidder").css("display", "block");
          }
      });
      
    },
    
    handlePhase: function(event){
      if(App.currentPhase=="3"){
        toastr["error"]("Auction ended");
      }else{
        var option={from:App.currentAccount} 
        App.contracts.BlindAuction.methods.advancePhase()
        .send(option)
        .on('receipt', function(receipt){          
          if(Object.keys(receipt.events).length>0){
            for (key in receipt.events) {
              if (receipt.events.hasOwnProperty(key)) {
                App.showNotification(key);
                $('.phase-notification-text').text(App.showNotification(key));
              }
            } 
          }         
          else{
            App.showNotification("AuctionEnded");
            $('.phase-notification-text').text("Auction ended");
          }
        })
        .on('error',(e)=>{
          toastr["error"]("Error in changing to next Event");
        })
      
    }
  },
      //Function to handle the bids
      handleBid: function() {
        event.preventDefault();
        var bidValue = $("#bet-value").val();
        var msgValue = $("#message-value").val();
        App.contracts.BlindAuction.methods.bid(bidValue)
        .send({from:App.currentAccount,value:web3.toWei(msgValue, "ether")})
        .on('receipt',receipt=>{
          if(receipt.status){
            toastr.info("Your bid is placed!", "", {"iconClass": 'toast-info notification0'});
          }else{
            toastr["error"]("Error in Revealing. Bidding Reverted!");
          }
        })
      },
  
  
      //Function to reveal the bids
      handleReveal: function() {
        event.preventDefault();
        var bidRevealValue = $("#bet-reveal").val();
        var bidRevealSecret = $("#password").val(); 
        App.contracts.BlindAuction.methods.reveal(parseInt(bidRevealValue),bidRevealSecret)
        .send({from:App.currentAccount})
         .on('receipt',receipt=>{
            if(receipt.status){
              toastr.info("Your bid is revealed!", "", {"iconClass": 'toast-info notification0'});
            }else{
              toastr["error"]("Error in Revealing. Bidding Reverted!");
            }
           
         })
         .on('error',err=>{ if(err.message.indexOf('phaseError')!=-1){
          toastr["error"]("Error: Not in a valid phase.");
          }else if(err.message.indexOf('beneficiaryReveal')!=-1){
            toastr["error"]("Error: Beneficiary cannot reveal.Only bidders can.");
          } else{
          toastr["error"]("Revealing Failed!");
        }
        })
      
      },  
  handleClose:function(){
    if(App.currentPhase=='3'){
    App.contracts.BlindAuction.methods.closeAuction()
    .send({from:App.currentAccount})
    .on('receipt',receipt=>{
      if(receipt.status){
        toastr["error"]("Auction is closed!");
      }
    })
  }else{
    toastr["error"]("Not in a valid phase to close the auction!");
  }
  },
     
    handleWinner : function() {
      App.contracts.BlindAuction.methods.auctionEnd()
      .send({from:App.currentAccount})
      .on('receipt',receipt=>{

        if(Object.keys(receipt.events).length>0){
        var winner = receipt.events.AuctionEnded.returnValues.winner;
        var highestBid = App.web3.utils.fromWei(receipt.events.AuctionEnded.returnValues.highestBid,"ether");
        var text="<br><br><b>Winner: </b>"+winner+"<br><br><b>Highest Bid: </b>"+highestBid+" ETH";
        $('#winner').html(text);
        toastr.info("Highest bid is " + highestBid + " ETH <br>" + "Winner is " + winner, "", {"iconClass": 'toast-info notification3'});
        }         
       
      })
      .on('error',e=>{
        toastr["error"]("Not in a valid phase to get the auction winner!");
      })
     },
    handleWithdraw:function(){
      if(parseInt(App.currentPhase)==3){
        App.contracts.BlindAuction.methods.withdraw()
        .send({from:App.currentAccount})
        .on('receipt',receipt=>{
         if(receipt.status){
          toastr.info('Your bid has been withdrawn');
         }
        })
        .on('error',e=>{
          toastr["error"]("Error in withdrawing the bid");
        })
      }else{
        toastr["error"]("Not in a valid phase to withdraw bid!");
      }  
  },
    //Function to show the notification of auction phases
    showNotification: function(phase){
        var phaseId=App.biddingPhases[phase]
        var phaseText=App.auctionPhases[phaseId];
        $('#phase-notification-text').text(phaseText);
        toastr.info(phaseText, "", {"iconClass": 'toast-info notification' + phaseId});
    }
  };
  
  
  $(function() {
    $(window).load(function() {
        App.init();
        //Notification UI config
        toastr.options = {
            "showDuration": "1000",
            "positionClass": "toast-top-left",
            "preventDuplicates": true,
            "closeButton": true
        };
    });
  });
  