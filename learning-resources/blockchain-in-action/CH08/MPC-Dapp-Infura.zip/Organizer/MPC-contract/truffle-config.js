const HDWalletProvider = require('truffle-hdwallet-provider');
organizer='tired peasant imitate party decrease inner metal arrive concert theme fit sock';
worker='illegal damp annual glory turtle cart umbrella vault own gentle rate bind';
module.exports = {
  networks: {
    ropsten: {
      provider: () => new HDWalletProvider(organizer, 'https://ropsten.infura.io/v3/eeff08826e1c48c3ad6fc6bd371949cc'),
      network_id: 3,       
      gas: 1000000,       
      skipDryRun: true
    },
    development: {
      host: "localhost",
      port: 7545,
      network_id: "*" // Match any network id
    }
  },

  compilers: {
    solc: {
       version: "0.5.8"
    }
  }
};