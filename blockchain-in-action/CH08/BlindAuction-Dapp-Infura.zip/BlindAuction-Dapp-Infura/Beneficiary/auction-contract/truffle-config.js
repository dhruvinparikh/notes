const HDWalletProvider = require('truffle-hdwallet-provider');
beneficiary='artist benefit glory cream doctor trim victory rule remain mixed praise chronic';
module.exports = {
  networks: {
    ropsten: {
      provider: () => new HDWalletProvider(beneficiary, 'https://ropsten.infura.io/v3/61e24519480f4ab6b1d5e793baab5c9b'),
      network_id: 3,       
      gas: 5000000,       
      skipDryRun: false
    },
    development: {
      host: "localhost",
      port: 7545,
      network_id: "*" // Match any network id
    }
  },

  compilers: {
    solc: {
       version: "0.5.8"
    }
  }
};