var MPC = artifacts.require("MPC");

module.exports = function(deployer,networks,accounts) {
  var worker=accounts[1]; 
  var balance=50000000000000000000;
  if(networks=='ropsten'){
    var worker='0x05722B191338037660071d97A123d915cc473764';
    var balance=1000000000000000000;
    deployer.deploy(MPC,worker,{value:balance});
  }   
  
};
